package co.edu.unbosque.beans;

import co.edu.unbosque.controller.HttpClientSynchronous;
import co.edu.unbosque.model.Planet;
import co.edu.unbosque.util.AESUtil;
import jakarta.annotation.ManagedBean;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.persistence.Column;

@ManagedBean
@RequestScoped
public class CreateBean {

	private String name;
	private String first;
	private String second;
	private String third;
	private String result;
	private String output;

	public CreateBean() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getSecond() {
		return second;
	}

	public void setSecond(String second) {
		this.second = second;
	}

	public String getThird() {
		return third;
	}

	public void setThird(String third) {
		this.third = third;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}

	public void showSticky(String message, FacesMessage.Severity severity) {
		FacesContext.getCurrentInstance().addMessage("createButton",
				new FacesMessage(severity, "Sticky Message", message));
	}

	public void create() {
		try {
			String url = "http://localhost:8081/student/createstudentjson";
			String requestBody = "{\"username\":\"" + AESUtil.encrypt(name) + "\",\"first\":\"" + AESUtil.encrypt(first)
					+ "\",\"second\":\"" + AESUtil.encrypt(second) + "\",\"third\":\"" + AESUtil.encrypt(third) + "\"}";
			String response = HttpClientSynchronous.doPost(url, requestBody);
			if (response.startsWith("you")) {
				showSticky(response, FacesMessage.SEVERITY_INFO);
			} else if (response.startsWith("fact")) {
				showSticky(response, FacesMessage.SEVERITY_ERROR);
			} else if (response.startsWith("jaja")) {
				showSticky(response, FacesMessage.SEVERITY_WARN);
			} else {
				showSticky("Unexpected response: " + response, FacesMessage.SEVERITY_ERROR);
			}
		} catch (Exception e) {
			e.printStackTrace();
			showSticky("Error during validation", FacesMessage.SEVERITY_ERROR);
		}
	}

	public void show() {
		String url = "http://localhost:8081/student/getallstudent";
		String response = HttpClientSynchronous.doGet(url);
		output = response;

	}

}
