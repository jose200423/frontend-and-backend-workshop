package co.edu.unbosque.model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "planet")
public class Planet {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "nameplanet", nullable = false)
	private String nameplanet;
	@Column(name = "temperature", nullable = false)
	private double temperature;
	@Column(name = "gravity", nullable = false)
	private double gravity;
	@Column(name = "color", nullable = false)
	private String color;

	public Planet() {

	}

	public Planet(String nameplanet, double temperature, double gravity, String color) {
		this.nameplanet = nameplanet;
		this.temperature = temperature;
		this.gravity = gravity;
		this.color = color;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}


	public String getNameplanet() {
		return nameplanet;
	}

	public void setNameplanet(String nameplanet) {
		this.nameplanet = nameplanet;
	}

	public double getTemperature() {
		return temperature;
	}

	public void setTemperature(double temperature) {
		this.temperature = temperature;
	}

	public double getGravity() {
		return gravity;
	}

	public void setGravity(double gravity) {
		this.gravity = gravity;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}


}
