package co.edu.unbosque.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "notes")
public class Student {

	private @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long id;
	@Column(unique = true)
	private String username;
	@NotNull
	private String first;
	@NotNull
	private String second;
	@NotNull
	private String third;
	@NotNull
	private String result;

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(String username, @NotNull String first, @NotNull String second, @NotNull String third,
			@NotNull String result) {
		super();
		this.username = username;
		this.first = first;
		this.second = second;
		this.third = third;
		this.result = result;
	}
	
	public Student(String username, @NotNull String first, @NotNull String second, @NotNull String third) {
		super();
		this.username = username;
		this.first = first;
		this.second = second;
		this.third = third;
		
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getFirst() {
		return first;
	}

	public void setFirst(String first) {
		this.first = first;
	}

	public String getSecond() {
		return second;
	}

	public void setSecond(String second) {
		this.second = second;
	}

	public String getThird() {
		return third;
	}

	public void setThird(String third) {
		this.third = third;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", username=" + username + ", first=" + first + ", second=" + second + ", third="
				+ third + ", result=" + result + "]";
	}

	

}
