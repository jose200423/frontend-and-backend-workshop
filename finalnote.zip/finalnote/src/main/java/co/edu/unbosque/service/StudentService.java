package co.edu.unbosque.service;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.edu.unbosque.model.Student;
import co.edu.unbosque.model.Student;
import co.edu.unbosque.repository.StudentRepository;
import co.edu.unbosque.util.AESUtil;

@Service
public class StudentService implements CRUDOperations<Student> {

	@Autowired
	private StudentRepository studRep;

	public StudentService() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int create(Student data) {
		if (findStudentnameAlreadyTaken(data)) {
			return 1;
		} else if (anyFieldEmpty(data)) {
			return 2;
		} else {
			String r = finalNote(data);
			Student temp = new Student(AESUtil.encrypt(data.getUsername()), AESUtil.encrypt(data.getFirst()),
					AESUtil.encrypt(data.getSecond()), AESUtil.encrypt(data.getThird()), AESUtil.encrypt(r));
			studRep.save(temp);
		}
		return 0;
	}

	@Override
	public List<Student> getAll() {
		List<Student> database = studRep.findAll();
		List<Student> decrypted = new ArrayList<>();

		for (Student data : database) {
			Student newS = new Student();
			newS.setId(data.getId());
			newS.setUsername(AESUtil.decrypt(data.getUsername()));
			newS.setFirst(AESUtil.decrypt(data.getFirst()));
			newS.setSecond(AESUtil.decrypt(data.getSecond()));
			newS.setThird(AESUtil.decrypt(data.getThird()));
			newS.setResult(AESUtil.decrypt(data.getResult()));
			decrypted.add(newS);
		}

		return decrypted;
	}

	@Override
	public int deleteById(Long id) {
		Optional<Student> found = studRep.findById(id);
		if (found.isPresent()) {
			studRep.delete(found.get());
			return 0;
		} else {
			return 1;
		}
	}

	@Override
	public int update(Long id, Student newData) {
		Optional<Student> found = studRep.findById(id);
		Optional<Student> newFound = studRep.findByUsername(newData.getUsername());
		if (found.isPresent() && !newFound.isPresent()) {
			Student temp = found.get();
			temp.setUsername(AESUtil.encrypt(newData.getUsername()));
			temp.setFirst(AESUtil.encrypt(newData.getFirst()));
			temp.setSecond(AESUtil.encrypt(newData.getSecond()));
			temp.setThird(AESUtil.encrypt(newData.getThird()));
			studRep.save(temp);
			return 0;
		} else if (found.isPresent() && newFound.isPresent()) {
			return 1;
		} else if (!found.isEmpty()) {
			return 2;
		} else {
			return 3;
		}

	}

	@Override
	public long count() {
		return studRep.count();
	}

	@Override
	public boolean exists(Long id) {

		return studRep.existsById(id) ? true : false;
	}

	public boolean findStudentnameAlreadyTaken(Student newStudent) {
		String encryptedUsername = AESUtil.encrypt(newStudent.getUsername());
		Optional<Student> found = studRep.findByUsername(encryptedUsername);
		if (found.isPresent()) {
			return true;
		} else {
			return false;
		}
	}

	public String finalNote(Student newStudent) {
		try {
			String firstNote = newStudent.getFirst();
			String secondNote = newStudent.getSecond();
			String thirdNote = newStudent.getThird();
			double note1 = Double.parseDouble(firstNote) * 0.30;
			double note2 = Double.parseDouble(secondNote) * 0.30;
			double note3 = Double.parseDouble(thirdNote) * 0.40;
			double finalNote = note1 + note2 + note3;
			
			String n = String.valueOf(finalNote);
			return n;
		} catch (NumberFormatException e) {
			return "Error whir your notes";
		}
	}

	private boolean anyFieldEmpty(Student data) {
		return data.getUsername().isEmpty() || data.getFirst().isEmpty() || data.getSecond().isEmpty()
				|| data.getThird().isEmpty();
	}

}
