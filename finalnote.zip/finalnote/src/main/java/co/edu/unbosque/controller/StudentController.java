package co.edu.unbosque.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.edu.unbosque.model.Student;
import co.edu.unbosque.service.StudentService;
import co.edu.unbosque.util.AESUtil;
import jakarta.transaction.Transactional;

@RestController
@RequestMapping("/student")
@CrossOrigin(origins = { "http://localhost:8080", "http://localhost:8081", "*" })
@Transactional
public class StudentController {

	@Autowired
	private StudentService stuServ;

	public StudentController() {
		// TODO Auto-generated constructor stub
	}

	@PostMapping(path = "/createstudentjson", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> createNewUserWithJson(@RequestBody Student newStudent) {
		Student temp = new Student(AESUtil.decrypt2(newStudent.getUsername()), AESUtil.decrypt2(newStudent.getFirst()),
				AESUtil.decrypt2(newStudent.getSecond()), AESUtil.decrypt2(newStudent.getThird()));
		int status = stuServ.create(temp);
		if (status == 0) {
			double n = Double.parseDouble(stuServ.finalNote(temp));
			
			if (n == 3) {
				return new ResponseEntity<String>("jaja you barely passed " + n, HttpStatus.CREATED);
			} else if (n > 3) {
				return new ResponseEntity<String>("you had a good time " + n, HttpStatus.CREATED);
			} else {
				return new ResponseEntity<String>("fact you lost better cry " + n, HttpStatus.CREATED);
			}
		} else if (status == 1) {
			return new ResponseEntity<>("Error: Username already taken", HttpStatus.CONFLICT);
		}else if (status == 2) {
			return new ResponseEntity<>("Error: it is necessary to fill out all the fields", HttpStatus.CONFLICT);
		} else {
			return new ResponseEntity<>("Error creating the user", HttpStatus.NOT_ACCEPTABLE);
		}
	}

	@GetMapping(path = "/getallstudent")
	public ResponseEntity<List<Student>> getAll() {
		List<Student> users = stuServ.getAll();
		if (users.isEmpty()) {
			return new ResponseEntity<List<Student>>(users, HttpStatus.NO_CONTENT);
		} else {
			return new ResponseEntity<List<Student>>(users, HttpStatus.ACCEPTED);
		}
	}

}
