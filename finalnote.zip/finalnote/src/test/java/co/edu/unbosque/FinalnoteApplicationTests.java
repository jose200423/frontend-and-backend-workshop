package co.edu.unbosque;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinalnoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
